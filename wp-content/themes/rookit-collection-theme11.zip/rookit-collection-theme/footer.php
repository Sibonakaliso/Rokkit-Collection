<footer class="site-footer">
    <div class="container footer-inner">
        <p>
            &copy; <?php echo esc_html(wp_date('Y')); ?>
            Rookit Collection. All rights reserved.
        </p>
        <p>Everyday style, made simple.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
